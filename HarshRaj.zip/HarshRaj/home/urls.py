from django.urls import path
from . import views

urlpatterns = [
      path('',views.home,name='home'),
      path('signin/', views.signin, name='signin'),
      path('task/', views.task, name='task'),
      path('taskAdd/', views.taskAdd, name='taskAdd'),
      path('taskdetails/<str:hm>/', views.taskDetails, name='details'),
      path('projectsDelete/<str:id>/', views.projectDelete, name='projectDelete'),
      path('projectsUpdate/<str:id>/', views.projectUpdate, name='projectUpdate'),
      path('logout/', views.logoutpage, name="logout"),

]

