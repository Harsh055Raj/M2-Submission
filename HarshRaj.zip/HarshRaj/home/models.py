from django.db import models

# Create your models here.
from django.db import models

# Create your models here.
class Task(models.Model):
    name=models.CharField(max_length=100,null=True,blank=True)
    description=models.CharField(max_length=100,null=True,blank=True)
    updated_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class PersonInfo(models.Model):
    name=models.CharField(max_length=100)
    Age=models.IntegerField(max_length=10)
    description=models.CharField(max_length=400)

    updated_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name