from django.shortcuts import render,redirect
from .models import Task,PersonInfo
from .forms import ProjectForms
from django.contrib import messages
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
# Create your views here.
def home(request):
    return render(request,'index.html')

def signin(request):
    if request.method=='POST':
        name=request.POST['Name']
        password=request.POST['password']
        user=authenticate(request,username=name,password=password)
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            return redirect('home')

    return render(request,'signin.html')

def task(request):
    try:
        data =  Task.objects.all()
        context = {"project": data}
    except Exception as e:
        context={"Task":"Data not Found"}

    return render(request,'task.html',context)

def taskAdd(request):

    form=ProjectForms()
    if request.method=='POST':
        myData = ProjectForms(request.POST)
        if myData.is_valid():
            myData.save()
            messages.success(request,'Project Added Sucessfully')

            return redirect('task')
    context = {"form": form}
    return render(request,'taskAdd.html',context)



def taskDetails(request,hm):
    fetchData=Task.objects.get(name=hm)
    #filter is the where clause
    # print(fetchData.query)
    # print(fetchData)
    context={"fetchData":fetchData}
    return render(request,'taskdetails.html',context)

def projectDelete(request,id):
    data=Task.objects.get(id=id)
    data.delete()

    return redirect('task')

def projectUpdate(request,id):
    myData=Task.objects.get(id=id)
    updateform=ProjectForms(request.POST or None,instance=myData)
    if updateform.is_valid():
        updateform.save()
        return redirect('task')
    context={"form":updateform}
    return render(request,'projectUpdate.html',context)

def logoutpage(request):
    logout(request)
    return redirect('home')